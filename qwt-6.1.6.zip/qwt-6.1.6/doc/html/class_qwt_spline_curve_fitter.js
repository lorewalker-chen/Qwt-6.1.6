var class_qwt_spline_curve_fitter =
[
    [ "FitMode", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8", [
      [ "Auto", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8ae19b8325da178d410cf10b04ed5a5df6", null ],
      [ "Spline", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8a97f3e821b70470f056b60a883229ec13", null ],
      [ "ParametricSpline", "class_qwt_spline_curve_fitter.html#a8c5e6858f885b5691c30092a950879a8a877f71e694ae9a2e33533a3fb5065c66", null ]
    ] ],
    [ "QwtSplineCurveFitter", "class_qwt_spline_curve_fitter.html#a98ae80240b254df85dcc44e1f3e4e830", null ],
    [ "~QwtSplineCurveFitter", "class_qwt_spline_curve_fitter.html#a933ecbf859698978104d0dd4ec2a2f6a", null ],
    [ "fitCurve", "class_qwt_spline_curve_fitter.html#ac91df6881bd84143efcc891344a84a7b", null ],
    [ "fitMode", "class_qwt_spline_curve_fitter.html#ae44a65faa0953ba390a4a17d8ebb7082", null ],
    [ "setFitMode", "class_qwt_spline_curve_fitter.html#a8381be57ee16b5a2bdacafbd5d71908b", null ],
    [ "setSpline", "class_qwt_spline_curve_fitter.html#a7f819ad010b19d58179655e4ceb1c6f1", null ],
    [ "setSplineSize", "class_qwt_spline_curve_fitter.html#af468f8218d57a2e8d07f4bf6aafda8dc", null ],
    [ "spline", "class_qwt_spline_curve_fitter.html#ac501260a25953e1ded6bbc84c3250fa8", null ],
    [ "spline", "class_qwt_spline_curve_fitter.html#a968c67ccf4ebf4642ceb9cf749e3642d", null ],
    [ "splineSize", "class_qwt_spline_curve_fitter.html#af7cc3a6b3dc82736e643bf5b346b2c6e", null ]
];