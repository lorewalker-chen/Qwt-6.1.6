var class_qwt_point_mapper =
[
    [ "TransformationFlags", "class_qwt_point_mapper.html#af7a8c38f6dd7faf8396a87a882e2f967", null ],
    [ "TransformationFlag", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23", [
      [ "RoundPoints", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23a0e367a1519b0005cad8bb324854cc8e3", null ],
      [ "WeedOutPoints", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23a288f41a8e4d53c895f7bffaaa9b5d9e4", null ]
    ] ],
    [ "QwtPointMapper", "class_qwt_point_mapper.html#a6e5eabb9c1af9b035023376fa2e1c472", null ],
    [ "~QwtPointMapper", "class_qwt_point_mapper.html#aabe6a70dae5784e8b67f4527c51e0c09", null ],
    [ "boundingRect", "class_qwt_point_mapper.html#a22846085780856a6ca36776d387d5b21", null ],
    [ "flags", "class_qwt_point_mapper.html#a3bed903e8aeaebd8153c6c75121bfb01", null ],
    [ "setBoundingRect", "class_qwt_point_mapper.html#a03910571df91575456e98134f6543650", null ],
    [ "setFlag", "class_qwt_point_mapper.html#a6e03e14718d3d66a0f6a02fec7fcaeed", null ],
    [ "setFlags", "class_qwt_point_mapper.html#ab556bd339cca487f25e2d894c51abe85", null ],
    [ "testFlag", "class_qwt_point_mapper.html#a5083f71473fd88e23363a587d84779f3", null ],
    [ "toImage", "class_qwt_point_mapper.html#a48feb94a44632dafc78405e7a42ee65e", null ],
    [ "toPoints", "class_qwt_point_mapper.html#ad580fc22b1bfcc353e711712cad15ae0", null ],
    [ "toPointsF", "class_qwt_point_mapper.html#a69d9ab6398de007d851e7d386ec5dfb7", null ],
    [ "toPolygon", "class_qwt_point_mapper.html#ab1dde54ddb1c522e17e28ff47fbaa82a", null ],
    [ "toPolygonF", "class_qwt_point_mapper.html#a394341ccba09dd293dddc7bb4f599891", null ]
];